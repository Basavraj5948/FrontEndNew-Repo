import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PreloadModule } from './preload/preload.module';
import { PreloadRoutingModule } from './preload/preload-routing.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,PreloadModule,PreloadRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
