import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutcomp',
  templateUrl: './aboutcomp.component.html',
  styleUrls: ['./aboutcomp.component.scss']
})
export class AboutcompComponent {

}
