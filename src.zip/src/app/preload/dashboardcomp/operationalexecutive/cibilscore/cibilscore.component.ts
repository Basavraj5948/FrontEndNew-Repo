import { Component } from '@angular/core';

@Component({
  selector: 'app-cibilscore',
  templateUrl: './cibilscore.component.html',
  styleUrls: ['./cibilscore.component.scss']
})
export class CibilscoreComponent {

}
