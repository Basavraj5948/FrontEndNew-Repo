import { Component } from '@angular/core';

@Component({
  selector: 'app-filevarification',
  templateUrl: './filevarification.component.html',
  styleUrls: ['./filevarification.component.scss']
})
export class FilevarificationComponent {

}
