import { Component } from '@angular/core';

@Component({
  selector: 'app-formfillup',
  templateUrl: './formfillup.component.html',
  styleUrls: ['./formfillup.component.scss']
})
export class FormfillupComponent {

}
