import { Component } from '@angular/core';

@Component({
  selector: 'app-sanctionletter',
  templateUrl: './sanctionletter.component.html',
  styleUrls: ['./sanctionletter.component.scss']
})
export class SanctionletterComponent {

}
