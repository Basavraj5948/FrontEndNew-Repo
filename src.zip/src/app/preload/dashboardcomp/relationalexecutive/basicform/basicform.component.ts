import { Component } from '@angular/core';

@Component({
  selector: 'app-basicform',
  templateUrl: './basicform.component.html',
  styleUrls: ['./basicform.component.scss']
})
export class BasicformComponent {

}
