import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CummunicatewithcustomerComponent } from './cummunicatewithcustomer.component';

describe('CummunicatewithcustomerComponent', () => {
  let component: CummunicatewithcustomerComponent;
  let fixture: ComponentFixture<CummunicatewithcustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CummunicatewithcustomerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CummunicatewithcustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
