import { Component } from '@angular/core';

@Component({
  selector: 'app-cummunicatewithcustomer',
  templateUrl: './cummunicatewithcustomer.component.html',
  styleUrls: ['./cummunicatewithcustomer.component.scss']
})
export class CummunicatewithcustomerComponent {

}
