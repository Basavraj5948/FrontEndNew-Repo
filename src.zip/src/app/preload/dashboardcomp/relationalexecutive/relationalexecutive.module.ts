import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RelationalexecutiveRoutingModule } from './relationalexecutive-routing.module';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { BasicformComponent } from './basicform/basicform.component';
import { CummunicatewithcustomerComponent } from './cummunicatewithcustomer/cummunicatewithcustomer.component';


@NgModule({
  declarations: [
    EnquiryComponent,
    BasicformComponent,
    CummunicatewithcustomerComponent
  ],
  imports: [
    CommonModule,
    RelationalexecutiveRoutingModule
  ],
  exports:[
    EnquiryComponent,
    BasicformComponent,
    CummunicatewithcustomerComponent
  ]
})
export class RelationalexecutiveModule { }
