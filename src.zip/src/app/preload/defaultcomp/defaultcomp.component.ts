import { Component } from '@angular/core';

@Component({
  selector: 'app-defaultcomp',
  templateUrl: './defaultcomp.component.html',
  styleUrls: ['./defaultcomp.component.scss']
})
export class DefaultcompComponent {

}
