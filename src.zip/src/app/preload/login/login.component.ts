import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  constructor(private fb:FormBuilder,private router:Router){}

  login:FormGroup;

  ngOnInit()
  {
    this.login=this.fb.group({
      username:[],
      password:[]
    })
  }

  loginMethod()
  {
      alert("login proccess started");
      if(this.login.get("username").value==="oe" && this.login.get("password").value==="oe")
      {
          alert("Login successfull for Operational Executive");
          localStorage.setItem("role","operationalexc");
          this.router.navigateByUrl("/dashboard/operationalexc");
         
          
      }
       else if(this.login.get("username").value==="re" && this.login.get("password").value==="re")
      {
          alert("Login successfull for Relational Executive");
          localStorage.setItem("role","relationalexe");
          this.router.navigateByUrl("/dashboard/relationalexe");
      }
      else if(this.login.get("username").value==="ah" && this.login.get("password").value==="ah")
      {
          alert("Login successfull for Account Head");
          localStorage.setItem("role","ah");
          this.router.navigateByUrl("/dashboard");
      }
      else if(this.login.get("username").value==="cm" && this.login.get("password").value==="cm")
      {
          alert("Login successfull for Credit Manager");
          localStorage.setItem("role","cm");
          this.router.navigateByUrl("/dashboard");
      }

  }

}
