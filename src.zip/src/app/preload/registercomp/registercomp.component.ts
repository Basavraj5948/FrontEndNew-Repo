import { Component } from '@angular/core';

@Component({
  selector: 'app-registercomp',
  templateUrl: './registercomp.component.html',
  styleUrls: ['./registercomp.component.scss']
})
export class RegistercompComponent {

}
